# FastAPI Task Management System

This project is a FastAPI-based task management system, using RabbitMQ for message queuing and asynchronous processing. The application architecture is designed to be modular, with a FastAPI application server and a separate consumer service that processes tasks.

## Project Architecture

The project includes the following main components:

1. **FastAPI App**: The core REST API server, providing endpoints to create and cancel tasks.
2. **Task Consumer**: A consumer service that listens to RabbitMQ messages to process tasks.
3. **RabbitMQ**: A message broker used to queue tasks between the FastAPI app and the consumer service.
4. **SQLite Database**: Stores task information.

### Using Docker Compose

To start the entire application stack, use Docker Compose. This will set up all services including the FastAPI API, RabbitMQ broker, and consumer.

1. **Clone the repository**

2. **Run the application stack**:
   ```bash
   docker-compose up --build
   ```

   This command starts:
   - **FastAPI App**: Runs on port `8000`, exposing the swagger document at `http://localhost:8000/docs#/`.
   - **RabbitMQ**: Exposes the default messaging port `5672` for AMQP and the management UI at `http://localhost:15672` (username: `guest`, password: `guest`).
   - **Consumer**: Processes tasks by listening to messages on the `task_queue` queue in RabbitMQ.

3. **Environment Variables**:
   - **FastAPI App** and **Consumer** both rely on environment variables to connect to RabbitMQ. The essential variables include:
     - `RABBITMQ_HOST`: Hostname for the RabbitMQ server, set as `rabbitmq` for internal networking in Docker.
     - `RABBITMQ_QUEUE_NAME`: Queue name for task processing, set as `task_queue` by default.
     - `RABBITMQ_USERNAME` and `RABBITMQ_PASSWORD`: RabbitMQ credentials, both default to `guest`.

4. **RabbitMQ Management UI**:
   - Access the RabbitMQ management interface at [http://localhost:15672](http://localhost:15672) with username `guest` and password `guest`.

### Running Tests

1. **Install Dependencies**:
   If not using Docker, install dependencies for local testing:
   ```bash
   pip install -r requirements.txt
   ```
2. **Run Tests: To execute tests using pytest, run**:
    ```bash
    pytest
    ```
