import asyncio
from contextlib import asynccontextmanager
import json
import aio_pika
import os
import logging
from dotenv import load_dotenv
from database import TaskStatusType, TaskDatabase, database, tasks

logging.basicConfig(level=logging.INFO)

# Set env variable
load_dotenv()
RABBITMQ_HOST = os.getenv("RABBITMQ_HOST")
RABBITMQ_QUEUE = os.getenv("RABBITMQ_QUEUE_NAME")
RABBITMQ_USERNAME = os.getenv("RABBITMQ_USERNAME")
RABBITMQ_PASSWORD = os.getenv("RABBITMQ_PASSWORD")

# inintial database
task_db = TaskDatabase(database)

@asynccontextmanager
async def database_lifespan():
    await task_db.connect()
    try:
        yield
    finally:
        await task_db.disconnect()

async def process_task(task_id: int):
    task = await task_db.get_task_by_id(task_id)
    
    logging.info(f"Ready to process task {task_id}")
    if not task:
        logging.info(f"Task {task_id} not found")
        return
    
    if task["status"] == TaskStatusType.Canceled:
        logging.info(f"Task {task_id} has been canceled")
        return

    await task_db.database.execute(
        tasks.update().where(tasks.c.id == task_id).values(status=TaskStatusType.Processing)
    )
    logging.info(f"Processing task {task_id}")

    await asyncio.sleep(3)

    await task_db.database.execute(
        tasks.update().where(tasks.c.id == task_id).values(status=TaskStatusType.Completed)
    )
    logging.info(f"Task {task_id} completed")

async def consume():
    connection_string = f"amqp://{RABBITMQ_USERNAME}:{RABBITMQ_PASSWORD}@{RABBITMQ_HOST}/"
    connection = await aio_pika.connect_robust(connection_string)
    channel = await connection.channel()
    queue = await channel.declare_queue(RABBITMQ_QUEUE, durable=True)

    async with database_lifespan():
        async with queue.iterator() as queue_iter:
            async for message in queue_iter:
                async with message.process():
                    task_data = json.loads(message.body)
                    task_id = task_data["task_id"]
                    await process_task(task_id)

if __name__ == "__main__":
    asyncio.run(consume())
