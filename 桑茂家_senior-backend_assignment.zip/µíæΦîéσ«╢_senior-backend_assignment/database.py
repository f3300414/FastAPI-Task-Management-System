import datetime
import enum
from databases import Database
from fastapi import HTTPException
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Enum, MetaData, Table
from sqlalchemy.sql import func

# Database setting
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
database = Database(SQLALCHEMY_DATABASE_URL)
metadata = MetaData()

class TaskStatusType(enum.Enum):
    Pending = "pending"
    Processing = "processing"
    Canceled = "canceled"
    Completed = "completed"

tasks = Table(
    "tasks",
    metadata,
    Column("id", Integer, primary_key=True, index=True),
    Column("message", String),
    Column("status", Enum(TaskStatusType), default=TaskStatusType.Pending),
    Column("create_date", DateTime, default=func.now()),
)

metadata.create_all(engine)

class TaskDatabase:
    def __init__(self, database: Database):
        self.database = database

    async def connect(self):
        await self.database.connect()

    async def disconnect(self):
        await self.database.disconnect()

    async def add_task(self, message: str, status: TaskStatusType = TaskStatusType.Pending):
        query = tasks.insert().values(message=message, status=status)
        task_id = await self.database.execute(query)
        return task_id

    async def get_task_by_id(self, task_id: int):
        query = tasks.select().where(tasks.c.id == task_id)
        task = await self.database.fetch_one(query)
        return task
    
    async def cancel_task(self, task_id: int):
        task = await self.get_task_by_id(task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        if task["status"] in [TaskStatusType.Canceled.value, TaskStatusType.Completed.value]:
            raise HTTPException(status_code=400, detail="Task cannot be canceled")
        
        update_query = tasks.update().where(tasks.c.id == task_id).values(status=TaskStatusType.Canceled)
        await self.database.execute(update_query)
        return {"message": "Task canceled successfully"}