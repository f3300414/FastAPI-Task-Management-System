import json
import logging
from fastapi import FastAPI
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session
from database import TaskDatabase, database
from rabbitmq_client import RabbitMQClient
from contextlib import asynccontextmanager

logging.basicConfig(level=logging.INFO)
app = FastAPI()
task_db = TaskDatabase(database)

class Payload(BaseModel):
    message: str

@asynccontextmanager
async def lifespan(app: FastAPI):
    await task_db.connect()
    yield
    await task_db.disconnect()

@app.post("/task/{task_id}/cancel",  status_code=204)
async def cancel_task(task_id: int):
    await task_db.cancel_task(task_id)
    return

@app.post("/task")
async def send_task(payload: Payload):
    # create new task
    task_id = await task_db.add_task(message=payload.message)

    # send task to RabbitMQ
    message_payload = json.dumps({"task_id": task_id, "message": payload.message})
    with RabbitMQClient() as rabbitmq_client:
        await rabbitmq_client.send_message(message_payload)
    
    return {"task_id": task_id}