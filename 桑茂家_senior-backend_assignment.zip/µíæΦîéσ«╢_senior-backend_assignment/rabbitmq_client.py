import pika
import os
from dotenv import load_dotenv

# Set env variable
load_dotenv()
RABBITMQ_HOST = os.getenv("RABBITMQ_HOST")
RABBITMQ_QUEUE = os.getenv("RABBITMQ_QUEUE_NAME")

class RabbitMQClient:
    def __init__(self, host=RABBITMQ_HOST):
        self.host = host
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(host=host, heartbeat=30))
        self.channel = self.connection.channel()
        self.channel.queue_declare(queue=RABBITMQ_QUEUE, durable=True)

    async def send_message(self, message: str):
        self.channel.basic_publish(
            exchange="",
            routing_key=RABBITMQ_QUEUE,
            body=message,
            properties=pika.BasicProperties(delivery_mode=2),  # make message persistent
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connection.close()