import pytest
import asyncio
from database import TaskStatusType, metadata
from databases import Database
from sqlalchemy import create_engine
from database import TaskDatabase

TEST_DATABASE_URL = "sqlite:///./unittest.db"
test_database = Database(TEST_DATABASE_URL)
test_engine = create_engine(TEST_DATABASE_URL)


task_db = TaskDatabase(test_database)

@pytest.fixture(scope="module")
async def setup_database():
    metadata.create_all(test_engine)
    await task_db.connect()
    yield
    await task_db.disconnect()
    metadata.drop_all(test_engine)

@pytest.mark.asyncio
async def test_add_task(setup_database):
    message = "Test message"
    task_id = await task_db.add_task(message=message)
    assert task_id is not None

    task = await task_db.get_task_by_id(task_id)
    assert task is not None
    assert task["message"] == message
    assert task["status"] == TaskStatusType.Pending

@pytest.mark.asyncio
async def test_get_task_by_id(setup_database):
    message = "Another task message"
    task_id = await task_db.add_task(message=message)
    
    task = await task_db.get_task_by_id(task_id)
    assert task is not None
    assert task["id"] == task_id
    assert task["message"] == message

@pytest.mark.asyncio
async def test_cancel_task(setup_database):
    task_id = await task_db.add_task(message="Canceled task message")
    await task_db.cancel_task(task_id)
    
    task = await task_db.get_task_by_id(task_id)
    assert task["status"] == TaskStatusType.Canceled
